-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2014 at 06:03 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `Dob` varchar(25) DEFAULT NULL,
  `gender` varchar(25) DEFAULT NULL,
  `pword` varchar(30) DEFAULT NULL,
  `repword` varchar(30) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `dep` varchar(20) DEFAULT NULL,
  `interest` varchar(30) DEFAULT NULL,
  UNIQUE KEY `uname_uniq` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`firstname`, `lastname`, `username`, `email`, `Dob`, `gender`, `pword`, `repword`, `url`, `dep`, `interest`) VALUES
('Manjula', 'Naik', 'manjula8', 'manjula@gmail.com', '20/08/95', 'female', 'apple2', 'apple2', 'http://www.github.com/manjula', 'Civil', 'watching movie, playing games,'),
('Bhavya', 'Shree', 'Bhavya', 'suchitranaik928@gmail.com', '07/08/95', 'female', 'manjula', 'manjula', 'http://www.github.com/manjula', 'Chemical', 'playing '),
('Suchitra', 'Naik', 'suchi', 'suchitran12@gmail.com', '05/08/93', 'female', 'greenblue', 'greenblue', 'https://www.github.com/suchi89', 'Computerscience', 'watching movies'),
('Teddy', 'House', 'Teddy', 'teddy@gmail.com', '09/08/96', 'male', 'mangoapple', 'mangoapple', 'http://www.github.com/teddy', 'production', 'watching cartoons, playing foo');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
