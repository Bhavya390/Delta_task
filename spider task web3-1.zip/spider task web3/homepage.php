<html>
<style>

h1
{
	color:white;
    text-align:center;


}

h2
{
	background-color:deepskyblue;
	color:white;
margin-top:0px;


}

html{
background:url(good.jpg)no-repeat center center fixed;
-webkit-background-size:cover;
-moz-background-size:cover;
background-size:cover;
}
.button{
color: white;
background-color: #3333cc;
margin-top:-50px;
margin-left:1150px;
padding-top:1px; 
 padding-bottom:1px; 
padding-right:1px;
padding-left:1px;
position:absolute;
width:50px;

}
</style>

<body>
<h2> Home page </h2>
<?php
	session_start();
	extract($_SESSION);
	extract($_POST);

$conn = mysqli_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysqli_select_db($conn,"test");
if(!$stat)
{
	die("Could not select the specified database");
}
$username=$_SESSION["username"] ;
if(!isset($username))
{
	header('location:login.html');
	exit();
	}
	
$query = "SELECT * FROM registration where username='$username'";

$status = mysqli_query($conn,$query);

	$row = mysqli_fetch_array($status);
if(!$status)
{
	die("Could not execute query");
}
else
{
	
	echo "<h1>Welcome $row[firstname] $row[lastname]</h1> ";
	
	 

}
mysqli_close($conn);
session_destroy();
?>
<a href="login.html"><input type="submit" value="logout" class="button" /></a>
</body>
</html>
