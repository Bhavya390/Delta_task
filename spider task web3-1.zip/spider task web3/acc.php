<html>
<style>
html{
background:url(good.jpg)no-repeat center center fixed;
-webkit-background-size:cover;
-moz-background-size:cover;
background-size:cover;
}
h1
{
	color:white;
    text-align:left;


}
</style>
<body>
<?php
	extract($_POST);
$conn = mysqli_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysqli_select_db($conn,"test");
if(!$stat)
{
	die("Could not select the specified database");
}
$query1 = "SELECT username FROM registration where username='$username'";
$status1 = mysqli_query($conn,$query1);
if(mysqli_num_rows($status1)!=0)
{
	die("<h1>user name already exists</h1>");
	}
	
$query = "INSERT INTO registration VALUES('$fname','$lname','$username','$email','$DOB','$gen','$pw','$rpw','$url','$dep','$interest')";
$status = mysqli_query($conn,$query);


if(!$status)
{
	die("Could not execute query");
}
if($username == "" || $pw == "" || $rpw==""|| $email==""||$DOB==""||$gen==""||$dep=="")
{
  echo "Some fields * are not filled ";
  
  header('location:account.html');
  }
else
{
	echo "<h1> REGISTERD Successfully!!!</h1>";
}
mysqli_close($conn);

?>
<?php
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& in_array($extension, $allowedExts)) {
  if ($_FILES["file"]["error"] > 0) {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
  } else {
    echo "Upload: " . $_FILES["file"]["name"] . "<br>";
    echo "Type: " . $_FILES["file"]["type"] . "<br>";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";
    if (file_exists("upload/" . $_FILES["file"]["name"])) {
      echo $_FILES["file"]["name"] . " already exists. ";
    } else {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "C:\server\www" . $_FILES["file"]["name"]);
      echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
    }
  }
} else {
  echo "Invalid file";
}
?>
<a href="login.html"><input type="submit" value="Backtologinpage" /></a>

</body>
</html>
