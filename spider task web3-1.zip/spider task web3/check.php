<html>
<style>
h1
{
	color:white;
    text-align:center;


}
</style>
<body>

<?php
	ob_start();
	extract($_POST);
	session_start();
$conn = mysql_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysql_select_db('test');
if(!$stat)
{
	die("Could not select the specified database");
}

$query = "SELECT * FROM registration where( username='$username' AND pword='$pw')";

$status = mysql_query($query);

	if(isset($username) && $username != "")
	{
		$_SESSION["username"] = $username;
	}
	else{
	echo"<h1>username and password not matching</h1>";
	}
	
	ob_flush();


if(mysql_num_rows($status)== 0)

{
	
	echo"<h1>username&password not matching</h1>";
	header('location:login.html');
	
}
else
{  
	header('location:homepage.php');
	}
mysql_close($conn);

?>

</body>
</html>








<!--<html>
<body>

	extract($_POST);
$conn = mysql_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysql_select_db('test');
if(!$stat)
{
	die("Could not select the specified database");
}
print("$username");
$query = "SELECT * FROM registration where( username='$username' AND pword='$pw')";
$status = mysql_query($query);
for($counter=0;$row=mysql_fetch_row($status);$counter++)
{
 foreach($row as $key-> $value)
 print ("$value");
 }
 
/*if($status)

{
	
	echo"<h2>username&password not matching</h2>";
	header('location:login.html');
}
else
{  
	header('location:homepage.html');
}*/

mysql_close($conn);

?>
</body>
</html>
-->
